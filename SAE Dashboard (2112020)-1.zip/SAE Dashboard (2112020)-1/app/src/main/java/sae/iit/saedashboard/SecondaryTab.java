package sae.iit.saedashboard;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import java.util.List;
import java.util.ArrayList;
import android.widget.ListView;
import android.widget.ArrayAdapter;
import androidx.fragment.app.Fragment;

/*Designer: Deep Trapasia
SAE Electrical Team Member(Software Team) 2019-2020
 */

public class SecondaryTab extends Fragment {
	//======================================
	//BMS(Battery Management System) datalogging variables
	private double BMSbatteryVoltage;
	private double BMSBatteryTemp;
	private double BMSPowerUsage;
	private double BMSBatteryAmperage;
	private double BMSAverageSpeed;
	private double BMSActiveAeroPosition;

	//Left Motor Data logging variables
	private double LeftMotorTemp;

	//Right Motor Data logging variables
	private double RightMotorTemp;
	//============================
	//BMS datalogging
	private String [] BMSaddress1;
	private String [] BMSaddress2;
	private String [] BMSaddress3;
	private String [] BMSaddress10;
	private String [] BMSaddress4;
	private String [] BMSaddress5;

	//Left Motor Data logging
	private String [] LeftMotorAddress3;

	//Right Motor Data logging
	private String [] RightMotorAddress15;
	//============================

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState){
		ViewGroup rootView = (ViewGroup) inflater.inflate(R.layout.secondary_tab, container, false);


		//======================================================================================================================
		//CSV file will datalog all these addresses
		//BMS datalogging
		BMSaddress1 = new String[]{" -- Battery Voltage -- ", Double.toString(BMSbatteryVoltage), " Volts"};
		BMSaddress2 = new String[]{" -- Battery Temp -- ", Double.toString(BMSBatteryTemp), " F"};
		BMSaddress3 = new String[]{" -- Battery Amperage -- ", Double.toString(BMSBatteryAmperage), " F"};
		BMSaddress10 = new String[]{" -- Active Aeronautical Position -- ", Double.toString(BMSActiveAeroPosition), " Degrees"};
		BMSaddress4 = new String[]{" -- Power Usage -- ", Double.toString(BMSPowerUsage), " %"};
		BMSaddress5 = new String[]{" -- Average Speed -- ", Double.toString(BMSAverageSpeed), " mph"};

		//Left Motor Data logging
		LeftMotorAddress3 = new String[]{" -- Left Motor Temp -- ", Double.toString(LeftMotorTemp), " F"};

		//Right Motor Data logging
		RightMotorAddress15 = new String[]{" -- Right Motor Temp -- ", Double.toString(RightMotorTemp), " F"};
		//===========================================================================================================================

		String add1 = BMSaddress1[0] + "                 " +  BMSaddress1[1] + " " +  BMSaddress1[2];
		String add2 = BMSaddress2[0] + "                 " +  BMSaddress2[1] + " " +  BMSaddress2[2];
		String add3 = LeftMotorAddress3[0] + "                 " + LeftMotorAddress3[1] + " " + LeftMotorAddress3[2];
		String add4 = BMSaddress4[0] + "                 " + BMSaddress4[1] + " " + BMSaddress4[2];
		String add5 = BMSaddress5[0] + "                 " + BMSaddress5[1] + " " + BMSaddress5[2];
		String add10 = BMSaddress10[0] + "                 " + BMSaddress10[1] + " " + BMSaddress10[2];
		String add15 = RightMotorAddress15[0] + "                 " + RightMotorAddress15[1] + " " + RightMotorAddress15[2];
		//=====================================================================================
		//Left motor datalogger
		ListView t1 = rootView.findViewById(R.id.simpleListView1);
		List<String> list1 = new ArrayList<String>();

		list1.add(add3);

		//Right motor datalogger
		ListView t2 = rootView.findViewById(R.id.simpleListView2);
		List<String> list2 = new ArrayList<String>();

		list2.add(add15);


		//BMS (Battery Management System) datalogger
		ListView t3 = rootView.findViewById(R.id.simpleListView3);
		List<String> list3 = new ArrayList<String>();

		list3.add(add1);
		list3.add(add3);
		list3.add(add2);
		list3.add(add4);
		list3.add(add5);
		list3.add(add10);

		//Left motor data List Maker (rowed)
		ArrayAdapter<String> arrayAdapter1 = new ArrayAdapter<String>(getActivity(), R.layout.rows, list1);
		t1.setAdapter(arrayAdapter1);
		//Right motor data List Maker (rowed)
		ArrayAdapter<String> arrayAdapter2 = new ArrayAdapter<String>(getActivity(), R.layout.rows, list2);
		t2.setAdapter(arrayAdapter2);
		//BMS (Battery Management System) List Maker (rowed)
		ArrayAdapter<String> arrayAdapter3 = new ArrayAdapter<String>(getActivity(), R.layout.rows, list3);
		t3.setAdapter(arrayAdapter3);

		//=======================================================================================


		return rootView;
	}

	public void update(double[] data) {
		//===============================BMS Setters (Battery Management System)===================
		//Battery Voltage
		BMSaddress1[1] = Double.toString(data[0]);
		//Battery Temp
		BMSaddress2[1] = Double.toString(data[1]);
		//Power usage =========== Battery Current * Battery Voltage
		this.BMSPowerUsage = data[0] * data[9];
		BMSaddress4[1] = Double.toString(BMSPowerUsage);
		//Battery Amperage
		BMSaddress3[1] = Double.toString(data[9]);
		//Average Speed
		BMSaddress5[1] = Double.toString(data[2]);
		//Active Aero Position
		BMSaddress10[1] = Double.toString(data[7]);
		//================================Left Motor Controller Setters============================
		//Left Motor Temp
		LeftMotorAddress3[1] = Double.toString(data[3]);
		//===============Right Motor Controller setters================================
		//Right Motor Temp
		RightMotorAddress15[1] = Double.toString(data[4]);
	}

}
