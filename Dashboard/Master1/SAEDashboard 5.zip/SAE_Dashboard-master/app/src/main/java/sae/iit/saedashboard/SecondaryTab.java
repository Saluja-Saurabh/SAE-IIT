package sae.iit.saedashboard;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import java.util.List;
import java.util.ArrayList;
import android.widget.ListView;
import android.widget.ArrayAdapter;
import androidx.fragment.app.Fragment;

public class SecondaryTab extends Fragment {

    TextView batteryVoltage;
    TextView batteryTemp;
    TextView ampsPulled;
    TextView motorTemp;
    private SecondaryTab secondaryTab;
    private ListView lv1;
    private ListView lv2;
    private ListView lv3;

    //Creates a view that is compatible with ViewPager
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState){
        ViewGroup rootView = (ViewGroup) inflater.inflate(R.layout.secondary_tab, container, false);

        ListView lv1 = rootView.findViewById(R.id.simpleListView1);
        List<String> your_array_list1 = new ArrayList<String>();
        your_array_list1.add("Battery Voltage");
        your_array_list1.add("Battery Temperature");
        your_array_list1.add("Motor Temperature");
        your_array_list1.add("Power Usage");
        your_array_list1.add("A");
        your_array_list1.add("B");
        your_array_list1.add("C");
        your_array_list1.add("D");
        your_array_list1.add("Battery Voltage");
        your_array_list1.add("Battery Temperature");
        your_array_list1.add("Motor Temperature");
        your_array_list1.add("Power Usage");
        your_array_list1.add("A");
        your_array_list1.add("B");
        your_array_list1.add("C");
        your_array_list1.add("D");

        ArrayAdapter<String> arrayAdapter1 = new ArrayAdapter<String>(getActivity(), R.layout.rows, your_array_list1);
        lv1.setAdapter(arrayAdapter1);

        ListView lv2 = rootView.findViewById(R.id.simpleListView2);
        List<String> your_array_list2 = new ArrayList<String>();
        your_array_list2.add("1111");
        your_array_list2.add("2222");
        your_array_list2.add("3333");
        your_array_list2.add("4444");
        your_array_list2.add("1111");
        your_array_list2.add("2222");
        your_array_list2.add("3333");
        your_array_list2.add("4444");
        your_array_list2.add("1111");
        your_array_list2.add("2222");
        your_array_list2.add("3333");
        your_array_list2.add("4444");
        your_array_list2.add("1111");
        your_array_list2.add("2222");
        your_array_list2.add("3333");
        your_array_list2.add("4444");

        ArrayAdapter<String> arrayAdapter2 = new ArrayAdapter<String>(getActivity(),R.layout.rows, your_array_list2);
        lv2.setAdapter(arrayAdapter2);

        ListView lv3 = rootView.findViewById(R.id.simpleListView3);
        List<String> your_array_list3 = new ArrayList<String>();
        your_array_list3.add("V");
        your_array_list3.add("Fahrenheit");
        your_array_list3.add("Fahrenheit");
        your_array_list3.add("%");
        your_array_list3.add("V");
        your_array_list3.add("Fahrenheit");
        your_array_list3.add("Fahrenheit");
        your_array_list3.add("%");
        your_array_list3.add("V");
        your_array_list3.add("Fahrenheit");
        your_array_list3.add("Fahrenheit");
        your_array_list3.add("%");
        your_array_list3.add("V");
        your_array_list3.add("Fahrenheit");
        your_array_list3.add("Fahrenheit");
        your_array_list3.add("%");

        ArrayAdapter<String> arrayAdapter3 = new ArrayAdapter<String>(getActivity(), R.layout.rows, your_array_list3);
        lv3.setAdapter(arrayAdapter3);

        return rootView;
    }

    //Updates info fields
    public void setBatteryVoltage(double voltage) {
        batteryVoltage.setText(String.valueOf(voltage));
    }

    public void setBatteryTemp(double temp) {
        batteryTemp.setText(String.valueOf(temp));
    }

    public void setAmpsPulled(double amps) {
        ampsPulled.setText(String.valueOf(amps));
    }

    public void setMotorTemp(double temp) {
        motorTemp.setText(String.valueOf(temp));
    }

}
