package sae.iit.saedashboard;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;
import java.util.List;
import java.util.ArrayList;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import com.google.android.material.tabs.TabLayout;

public class MainActivity extends AppCompatActivity {

    //Initializing variables
    private static final int NUM_OF_TABS = 4;
    private ViewPager viewPager;
    private MyPagerAdapter pagerAdapter;
    private TabLayout tabLayout;
    private MainTab mainTab;
    private SecondaryTab secondaryTab;
    private ListView lv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        //Runs at start of program
        super.onCreate(savedInstanceState);


        setContentView(R.layout.activity_main);
        //Hides the status bar.
        View decorView = getWindow().getDecorView();
        int uiOptions = View.SYSTEM_UI_FLAG_FULLSCREEN;
        decorView.setSystemUiVisibility(uiOptions);
        //Setting up ViewPager, Adapter, and TabLayout
        viewPager = findViewById(R.id.viewPager);
        pagerAdapter = new MyPagerAdapter(getSupportFragmentManager());
        tabLayout = findViewById(R.id.tabLayout);
        viewPager.setAdapter(pagerAdapter);
        tabLayout.setupWithViewPager(viewPager);
        tabLayout.setTabTextColors(getResources().getColor(R.color.white),getResources().getColor(R.color.white));


    }

    protected void onResume(Bundle savedInstanceState) {
        //Hides the status bar.
        View decorView = getWindow().getDecorView();
        int uiOptions = View.SYSTEM_UI_FLAG_FULLSCREEN;
        decorView.setSystemUiVisibility(uiOptions);
    }

    //Updates display on tablet
    //Will receive an array
    public void update() {
        //HAS PLACE HOLDER VALUES IN SET METHOD CALLS
        //Gets fragment instances
        mainTab = (MainTab) getSupportFragmentManager().findFragmentById(R.id.mainTab);
        secondaryTab = (SecondaryTab) getSupportFragmentManager().findFragmentById(R.id.secondaryTab);
        //Main tab fields
        mainTab.setSpeedometer(3);
        mainTab.setBatteryLife(275);
        mainTab.setPowerGauge(40);
        //Secondary tab field
        secondaryTab.setBatteryVoltage(275);
        secondaryTab.setBatteryTemp(87);

    }

}
