package sae.iit.saedashboard;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import java.util.List;
import java.util.ArrayList;
import android.widget.ListView;
import android.widget.ArrayAdapter;
import androidx.fragment.app.Fragment;

public class SecondaryTab extends Fragment {

    double batteryVoltage;
    double BatteryTemp;
    double LeftMotorTemp;
    double PowerUsage;
    double AverageSpeed;
    double RightMotorTemp;
    double PhaseATemp;
    double PhaseBTemp;
    double PhaseCTemp;
    double ActiveAeroPosition;
    double PhaseACurrent;
    double PhaseBCurrent;
    double  PhaseCCurrent;
    double  DCBusCurrent;
    String [] address1;
    String [] address2;
    String [] address3;
    String [] address4;
    String [] address5;
    String [] address6;
    String [] address7;
    String [] address8;
    String [] address9;
    String [] address10;
    String [] address11;
    String [] address12;
    String [] address13;
    String [] address14;


    //Creates a view that is compatible with ViewPager
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState){
        ViewGroup rootView = (ViewGroup) inflater.inflate(R.layout.secondary_tab, container, false);

        ListView list = rootView.findViewById(R.id.simpleListView1);
        List<String> t = new ArrayList<String>();
        address1  = new String[] {"1 -- Battery Voltage -- ",Double.toString(batteryVoltage)," Volts"};
        address2  = new String[] {"2 -- BatteryTemp -- ",Double.toString(BatteryTemp)," F"};
        address3  = new String[] {"3 -- LeftMotorTemp -- ",Double.toString(LeftMotorTemp)," F"};
        address4  = new String[] {"4 -- PowerUsage -- ",Double.toString(PowerUsage)," %"};
        address5  = new String[] {"5 -- AverageSpeed -- ",Double.toString(AverageSpeed)," mph"};
        address6  = new String[] {"6 -- RightMotorTemp -- ",Double.toString(RightMotorTemp)," F"};
        address7  = new String[] {"7 -- PhaseATemp -- ",Double.toString(PhaseATemp)," F"};
        address8  = new String[] {"8 -- PhaseBTemp -- ", Double.toString(PhaseBTemp)," F"};
        address9  = new String[] {"9 -- PhaseCTemp -- ", Double.toString(PhaseCTemp)," F"};
        address10 = new String[] {"10 -- ActiveAeroPosition -- ", Double.toString(ActiveAeroPosition)," Degrees"};
        address11 = new String[] {"11 -- PhaseACurrent -- ",Double.toString(PhaseACurrent)," Amps"};
        address12 = new String[] {"12 -- PhaseBCurrent -- ",Double.toString(PhaseBCurrent)," Amps"};
        address13 = new String[] {"13 -- PhaseCCurrent -- ",Double.toString(PhaseCCurrent)," Amps"};
        address14 = new String[] {"14 -- DCBusCurrent -- ", Double.toString(DCBusCurrent),"  Amps"};

        String add1 =  address1[0]+ "                 "+address1[1]+" "+address1[2];
        String add2 =  address2[0]+ "                 "+address2[1]+" "+address2[2];
        String add3 =  address3[0]+ "                 "+address3[1]+" "+address3[2];
        String add4 =  address4[0]+ "                 "+address4[1]+" "+address4[2];
        String add5 =  address5[0]+ "                 "+address5[1]+" "+address5[2];
        String add6 =  address6[0]+ "                 "+address6[1]+" "+address6[2];
        String add7 =  address7[0]+ "                 "+address7[1]+" "+address7[2];
        String add8 =  address8[0]+ "                 "+address8[1]+" "+address8[2];
        String add9 =  address9[0]+ "                 "+address9[1]+" "+address9[2];
        String add10 = address10[0]+"                 "+address10[1]+" "+address10[2];
        String add11 = address11[0]+"                 "+address11[1]+" "+address11[2];
        String add12 = address12[0]+"                 "+address12[1]+" "+address12[2];
        String add13 = address13[0]+"                 "+address13[1]+" "+address13[2];
        String add14 = address14[0]+"                 "+address14[1]+" "+address14[2];

        t.add(add1);
        t.add(add2);
        t.add(add3);
        t.add(add4);
        t.add(add5);
        t.add(add6);
        t.add(add7);
        t.add(add8);
        t.add(add9);
        t.add(add10);
        t.add(add11);
        t.add(add12);
        t.add(add13);
        t.add(add14);

        setBatteryVoltage(32.0);

        ArrayAdapter<String> arrayAdapter3 = new ArrayAdapter<String>(getActivity(), R.layout.rows, t);
        list.setAdapter(arrayAdapter3);

        return rootView;
    }

    //Updates info fields
    public void setBatteryVoltage(double voltage) {
        address1[1] = Double.toString(batteryVoltage);
    }

    public void setBatteryTemp(double temp) {
        address2[1] = Double.toString(BatteryTemp);
    }

    public void setLeftMotorTemp(double temp) {
        address3[1] = Double.toString(LeftMotorTemp);
    }

    public void setPowerUsage(double BatteryVolts, double BatteryCurrent) {
        double powerUsage = BatteryCurrent*BatteryVolts;
        address4[1] = Double.toString(PowerUsage);
    }

    public void setAverageSpeed(double averageSpeed) {
        address5[1] = Double.toString(AverageSpeed);
    }

    public void setRightMotorTemp(double temp) {
        address6[1] = Double.toString(RightMotorTemp);
    }

    public void setPhaseATemp(double temp) {
        address7[1] =Double.toString(PhaseATemp);
    }

    public void setPhaseBTemp(double temp) {
        address8[1] = Double.toString(PhaseBTemp);
    }

    public void setPhaseCTemp(double temp) {
        address9[1] = Double.toString(PhaseCTemp);
    }

    public void setActiveAeroPosition(double degrees) {
        address10[1] = Double.toString(ActiveAeroPosition);
    }

    public void setPhaseACurrent(double amps) {
        address11[1] = Double.toString(PhaseACurrent);
    }

    public void setPhaseBCurrent(double amps) {
        address12[1] = Double.toString(PhaseBCurrent);
    }
    public void setPhaseCCurrent(double voltage) {
        address13[1] = Double.toString(PhaseCCurrent);
    }
    public void setDCBusCurrent(double amps) {
        address14[1] = Double.toString(DCBusCurrent);
    }

   //add more here

}
