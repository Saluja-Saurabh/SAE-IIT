package sae.iit.saedashboard;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import java.util.List;
import java.util.ArrayList;
import android.widget.ListView;
import android.widget.ArrayAdapter;
import androidx.fragment.app.Fragment;

public class SecondaryTab extends Fragment {
    double batteryVoltage;
    String [] address1;
    String [] address2;
    String [] address3;
    String [] address4;
    String [] address5;
    String [] address6;
    String [] address7;
    String [] address8;
    String [] address9;
    String [] address10;
    String [] address11;
    String [] address12;
    String [] address13;
    String [] address14;
    String [] address15;
    String [] address16;
    String [] address17;
    String [] address18;
    String [] address19;
    String [] address20;
    String [] address21;
    String [] address22;
    String [] address23;
    String [] address24;
    String [] address25;
    String [] address26;
    String [] address27;
    String [] address28;
    String [] address29;
    String [] address30;
    String [] address31;
    String [] address32;
    String [] address33;

    //Creates a view that is compatible with ViewPager
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState){
        ViewGroup rootView = (ViewGroup) inflater.inflate(R.layout.secondary_tab, container, false);

        ListView list = rootView.findViewById(R.id.simpleListView1);
        List<String> t = new ArrayList<String>();
        address1  = new String[] {"1             ",Double.toString(batteryVoltage),"         Volts"};
        address2  = new String[] {"2             ","22.90","          F"};
        address3  = new String[] {"3             ", "22","            F"};
        address4  = new String[] {"4             ", "22","            %"};
        address5  = new String[] {"5             ", "22","            mph"};
        address6  = new String[] {"6             ", "22","            F"};
        address7  = new String[] {"7             ", "22","            F"};
        address8  = new String[] {"8             ", "22","            F"};
        address9  = new String[] {"9             ", "22","            F"};
        address10 = new String[] {"10            ", "22","            Degrees"};
        address11 = new String[] {"11            ", "22","            Amps"};
        address12 = new String[] {"12            ", "22","            Amps"};
        address13 = new String[] {"13            ", "22","            Amps"};
        address14 = new String[] {"14            ", "22","            Amps"};
        address15 = new String[] {"15            ", "22","            Volts"};
        address16 = new String[] {"16            ", "22","            Volts"};
        address17 = new String[] {"17            ", "22","            Volts"};
        address18 = new String[] {"18            ", "22","            Volts"};
        address19 = new String[] {"19            ", "22","            Volts"};
        address20 = new String[] {"20            ", "22","            Volts"};
        address21 = new String[] {"21            ", "22","            Volts"};
        address22 = new String[] {"22            ", "22","            Volts"};
        address23 = new String[] {"23            ", "22","            Volts"};
        address24 = new String[] {"24            ", "22","            Volts"};
        address25 = new String[] {"25            ", "22","            Volts"};
        address26 = new String[] {"26            ", "22","            Volts"};
        address27 = new String[] {"27            ", "22","            Volts"};
        address28 = new String[] {"28            ", "22","            Volts"};
        address29 = new String[] {"29            ", "22","            Volts"};
        address30 = new String[] {"30            ", "22","            Volts"};
        address31 = new String[] {"31            ", "22","            Volts"};
        address32 = new String[] {"32            ", "22","            Volts"};
        address33 = new String[] {"33            ", "22","            Volts"};
        String add1 =  address1[0]+ "                 "+address1[1]+" "+address1[2];
        String add2 =  address2[0]+ "                 "+address2[1]+" "+address2[2];
        String add3 =  address3[0]+ "                 "+address3[1]+" "+address3[2];
        String add4 =  address4[0]+ "                 "+address4[1]+" "+address4[2];
        String add5 =  address5[0]+ "                 "+address5[1]+" "+address5[2];
        String add6 =  address6[0]+ "                 "+address6[1]+" "+address6[2];
        String add7 =  address7[0]+ "                 "+address7[1]+" "+address7[2];
        String add8 =  address8[0]+ "                 "+address8[1]+" "+address8[2];
        String add9 =  address9[0]+ "                 "+address9[1]+" "+address9[2];
        String add10 = address10[0]+"                 "+address10[1]+" "+address10[2];
        String add11 = address11[0]+"                 "+address11[1]+" "+address11[2];
        String add12 = address12[0]+"                 "+address12[1]+" "+address12[2];
        String add13 = address13[0]+"                 "+address13[1]+" "+address13[2];
        String add14 = address14[0]+"                 "+address14[1]+" "+address14[2];
        String add15 = address15[0]+"                 "+address15[1]+" "+address15[2];
        String add16 = address16[0]+"                 "+address16[1]+" "+address16[2];
        String add17 = address17[0]+"                 "+address17[1]+" "+address17[2];
        String add18 = address18[0]+"                 "+address18[1]+" "+address18[2];
        String add19 = address19[0]+"                 "+address19[1]+" "+address19[2];
        String add20 = address20[0]+"                 "+address20[1]+" "+address20[2];
        String add21 = address21[0]+"                 "+address21[1]+" "+address21[2];
        String add22 = address22[0]+"                 "+address22[1]+" "+address22[2];
        String add23 = address23[0]+"                 "+address23[1]+" "+address23[2];
        String add24 = address24[0]+"                 "+address24[1]+" "+address24[2];
        String add25 = address25[0]+"                 "+address25[1]+" "+address25[2];
        String add26 = address26[0]+"                 "+address26[1]+" "+address26[2];
        String add27 = address27[0]+"                 "+address27[1]+" "+address27[2];
        String add28 = address28[0]+"                 "+address28[1]+" "+address28[2];
        String add29 = address29[0]+"                 "+address29[1]+" "+address29[2];
        String add30 = address30[0]+"                 "+address30[1]+" "+address30[2];
        String add31 = address31[0]+"                 "+address31[1]+" "+address31[2];
        String add32 = address32[0]+"                 "+address32[1]+" "+address32[2];
        String add33 = address33[0]+"                 "+address33[1]+" "+address33[2];


        t.add(add1);
        t.add(add2);
        t.add(add3);
        t.add(add4);
        t.add(add5);
        t.add(add6);
        t.add(add7);
        t.add(add8);
        t.add(add9);
        t.add(add10);
        t.add(add11);
        t.add(add12);
        t.add(add13);
        t.add(add14);
        t.add(add15);
        t.add(add16);
        t.add(add17);
        t.add(add18);
        t.add(add19);
        t.add(add20);
        t.add(add21);
        t.add(add22);
        t.add(add23);
        t.add(add24);
        t.add(add25);
        t.add(add26);
        t.add(add27);
        t.add(add28);
        t.add(add29);
        t.add(add30);
        t.add(add31);
        t.add(add32);
        t.add(add33);


        ArrayAdapter<String> arrayAdapter3 = new ArrayAdapter<String>(getActivity(), R.layout.rows, t);
        list.setAdapter(arrayAdapter3);

        return rootView;
    }

    //Updates info fields
    public void setBatteryVoltage(double voltage) {
        address1[1]  = Double.toString(batteryVoltage);
    }

    public void setBatteryTemp(double temp) {
        address2[1] = String.valueOf(temp);
    }

    public void setLeftMotorTemp(double temp) {
        address3[1] = String.valueOf(temp);
    }

    public void setPowerUsage(double powerUsage) {
        address4[1] = String.valueOf(powerUsage);
    }
    public void setAverageSpeed(double averageSpeed) {
        address5[1] = String.valueOf(averageSpeed);
    }

    public void setRightMotorTemp(double temp) {
        address6[1] = String.valueOf(temp);
    }

    public void setPhaseATemp(double temp) {
        address7[1] = String.valueOf(temp);
    }

    public void setPhaseBTemp(double temp) {
        address8[1] = String.valueOf(temp);
    }

    public void setPhaseCTemp(double temp) {
        address9[1] = String.valueOf(temp);
    }

    public void setActiveAeroPosition(double degrees) {
        address10[1] = String.valueOf(degrees);
    }

    public void setPhaseACurrent(double amps) {
        address11[1] = String.valueOf(amps);
    }

    public void setPhaseBCurrent(double amps) {
        address12[1] = String.valueOf(amps);
    }
    public void setPhaseCCurrent(double voltage) {
        address13[1] = String.valueOf(voltage);
    }
    public void setDCBusCurrent(double amps) {
        address14[1] = String.valueOf(amps);
    }

   //add more here

}
