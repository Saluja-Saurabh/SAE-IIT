package sae.iit.saedashboard;

import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.fragment.app.Fragment;

import com.sccomponents.gauges.library.ScArcGauge;
import com.sccomponents.gauges.library.ScFeature;
import com.sccomponents.gauges.library.ScGauge;
import com.sccomponents.gauges.library.ScNotches;

import pl.pawelkleczkowski.customgauge.CustomGauge;

public class MainTab extends Fragment {

    private TextView speedometer, batteryLife, powerDisplay;
    private ScArcGauge powerGauge;
    private CustomGauge bLGauge;


    //Creates a view that is compatible with ViewPager
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        ViewGroup rootView = (ViewGroup) inflater.inflate(
            R.layout.main_tab, container, false);
        //Initializing Fields
        speedometer = rootView.findViewById(R.id.speedometer);
        batteryLife = rootView.findViewById(R.id.batteryLife);
        //Power Gauge
        powerGauge = rootView.findViewById(R.id.powerGauge);
        powerDisplay = rootView.findViewById(R.id.counter);
        // Clear all default features from the gauge
        powerGauge.removeAllFeatures();
        // Create the base notches.
        ScNotches base = (ScNotches) powerGauge.addFeature(ScNotches.class);
        base.setTag(ScGauge.BASE_IDENTIFIER);
        base.setPosition(ScFeature.Positions.INSIDE);
        base.setRepetitions(40);
        base.setWidths(10);
        base.setHeights(10, 120);
        base.setColors(Color.parseColor("#dbdfe6"));

        // Create the progress notches.
        ScNotches progress = (ScNotches) powerGauge.addFeature(ScNotches.class);
        progress.setTag(ScGauge.PROGRESS_IDENTIFIER);
        progress.setColors(
                Color.parseColor("#0BA60A"),
                Color.parseColor("#FEF301"),
                Color.parseColor("#EA0C01")
        );

        // Set the value
        powerGauge.setHighValue(0, 0, 100);

        // Changes the text value to the gauge value
        powerGauge.setOnEventListener(new ScGauge.OnEventListener() {
            @Override
            public void onValueChange(ScGauge gauge, float lowValue, float highValue, boolean isRunning) {
                // Write the value
                int value = (int) ScGauge.percentageToValue(highValue, 0, 13000);
                powerDisplay.setText(Integer.toString(value));
            }
        });
        bLGauge = rootView.findViewById(R.id.gauge1);
        bLGauge.setStartValue(0);
        bLGauge.setEndValue(100);

        return rootView;
    }

    //Updates field info
    public void setPowerGauge(float power) {
        powerGauge.setHighValue(convertPower(power));
    }

    private int convertPower(float power) {
        int percentage = (int)power / 400 * 100;
        return percentage;
    }

    public void setSpeedometer(int speed) {
        speedometer.setText(speed);
    }

    public void setBatteryLife(double battery) {
        int bLPercentage = convertBatteryLife(battery);
        batteryLife.setText(bLPercentage);
        bLGauge.setValue(bLPercentage);
    }

    private int convertBatteryLife(double battery) {
        //Assumes battery is voltage and max is 302.4V min is 216qV
        int percentage = (int)((battery - 216)/86.4*100.0);
        return percentage;
    }

}
