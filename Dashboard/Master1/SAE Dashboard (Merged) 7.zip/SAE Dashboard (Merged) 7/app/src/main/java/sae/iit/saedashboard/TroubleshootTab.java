package sae.iit.saedashboard;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.PopupWindow;
import android.view.ViewGroup.LayoutParams;
import android.widget.TextView;
import androidx.fragment.app.Fragment;
import static android.content.Context.LAYOUT_INFLATER_SERVICE;

/*Designer: Deep Trapasia
SAE Electrical Team Member(Software Team) 2019-2020
 */
public class TroubleshootTab extends Fragment implements View.OnClickListener {

    public Button TSPostRunHardwareGate;
    public Button TSPostRunCurrentSensor;
    public Button TSPostRunAccelerator;
    public Button TSPostRunTemperature;
    public Button TSPostRunVoltageSensor;
    public Button TSPostRunPreCharge;
    public Button TSPostRunEEPROM;
    public Button TSPostRunBrake;
    public Button TSRunCan;
    public Button TSRunDisCharge;
    public Button TSRunBrake;

    @Override
    public View onCreateView(final LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        final ViewGroup rootView = (ViewGroup) inflater.inflate(
                R.layout.troubleshoot_tab, container, false);
        //==========================================================================================
        TSPostRunHardwareGate = rootView.findViewById(R.id.TSPostRunHardwareGate);
        TSPostRunHardwareGate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                LayoutInflater layoutInflater
                        = (LayoutInflater) getContext()
                        .getSystemService(LAYOUT_INFLATER_SERVICE);
                View popupView = layoutInflater.inflate(R.layout.popup_window, null);
                final PopupWindow popupWindow = new PopupWindow(
                        popupView,
                        LayoutParams.WRAP_CONTENT,
                        LayoutParams.WRAP_CONTENT);
                String PostRunHardwareGate ="===========HARDWARE GATE/ DESATURATION FAULT==============="
                        + "\nPOST FAULT : Hardware Gate/Desaturation Fault"
                        + "\nFAULT INDICATOR NUMBER OF BLINKS : 5"
                        + "\nFAULT DESCRIPTION : A hardware de-saturation fault occurs for any of the following conditions:"
                        + "\n--The current exceeds normal level and causes short-circuit in an IGBT."
                        + "\n--An IGBT circuit is bad."
                        + "\n--An over-voltage condition occurs on DC bus."
                        + "\nCurrently, this fault cannot be cleared using the ‘Clear Fault Command’. In"
                        + "\norder to clear this fault, inverter power must be recycled."
                        + "\n==================HW OVER-CURRENT FAULT============="
                        + "\nPOST FAULT : HW Over-current Fault"
                        + "\nFAULT INDICATOR NUMBER OF BLINKS : 5"
                        + "\nFAULT DESCRIPTION : This fault occurs when any of the current sensors detect an over-current condition"
                        + "\nwhich could be positive or negative. All six over-current faults are ORed together"
                        + "to cause the HW over-current fault."
                        + "\n=================HARDWARE GATE/DESATURATION FAULT============="
                        + "\nRUN FAULT : Hardware Gate/Desaturation Fault"
                        + "\nFAULT INDICATOR NUMBER OF BLINKS : 5"
                        + "\nFAULT DESCRIPTION : A hardware de-saturation fault occurs for any of the following conditions:\n"
                        + "--The current exceeds normal level and causes short-circuit in an IGBT\n"
                        + "--An IGBT circuit is bad\n"
                        + "--An over-voltage condition occurs on DC bus\n"
                        + "Currently, this fault cannot be cleared using the ‘Clear Fault Command’. In\n"
                        + "order to clear this fault, inverter power must be recycled."
                        + "\n=============HARDWARE OVER-CURRENT FAULT============="
                        + "\nRUN FAULT : Hardware Over-current Fault"
                        + "\nFAULT INDICATOR NUMBER OF BLINKS : 5"
                        + "\nFAULT DESCRIPTION : This fault occurs when any of the current sensors detect an over-current condition"
                        + "\nwhich could be positive or negative. All six over-current faults are ORed together"
                        +"to cause the HW over-current fault.";
                TextView stringInfo2 = popupView.findViewById(R.id.textView2);
                stringInfo2.setText(PostRunHardwareGate);

                Button btnDismiss = popupView.findViewById(R.id.dismiss);
                btnDismiss.setOnClickListener(new Button.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        popupWindow.dismiss();
                    }
                });

                popupWindow.showAtLocation(rootView,0,0,0);
            }
        });
        //=========================================================================================
        TSPostRunCurrentSensor = rootView.findViewById(R.id.TSPostRunCurrentSensor);
        TSPostRunCurrentSensor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                LayoutInflater layoutInflater
                        = (LayoutInflater) getContext()
                        .getSystemService(LAYOUT_INFLATER_SERVICE);
                View popupView = layoutInflater.inflate(R.layout.popup_window, null);
                final PopupWindow popupWindow = new PopupWindow(
                        popupView,
                        LayoutParams.WRAP_CONTENT,
                        LayoutParams.WRAP_CONTENT);
                String PostRunCurrentSensor = "====================CURRENT SENSOR LOW======="
                        + "\nPOST FAULT : Current Sensor Low"
                        + "\nFAULT INDICATOR NUMBER OF BLINKS : 3"
                        + "\nFAULT DESCRIPTION : Current sensor reading is lower than the hard-coded value (-22.5 Amps) set for"
                        + "this fault."
                        + "\n=====================CURRENT SENSOR HIGH========="
                        + "\nPOST FAULT : Current Sensor High"
                        + "\nFAULT INDICATOR NUMBER OF BLINKS : 3"
                        + "\nFAULT DESCRIPTION : Current sensor reading is higher than the hard-coded value (22.5 Amps) set for\n" +
                        "this fault."
                        +"\n=====================OVER-CURRENT FAULT============="
                        + "\nRUN FAULT : Over-current Fault"
                        + "\nFAULT INDICATOR NUMBER OF BLINKS : 3"
                        + "\nFAULT DESCRIPTION : One or more of the three phase currents is above the hard-coded SW over-\n" +
                        "current limit. SW over-current limit can be checked from the monitored parameter"
                        +"\nlist by adding SW_Over_Current_(Amps)_x_10 to the watch list."
                        +"\n=======================CURRENT SENSOR FAULT============="
                        + "\nRUN FAULT : Current Sensor Fault"
                        + "\nFAULT INDICATOR NUMBER OF BLINKS :  3"
                        + "\nFAULT DESCRIPTION : If current readings are not within a certain range, current sensor is assumed to be\n" +
                        "mal-functioning.";
                TextView stringInfo2 = popupView.findViewById(R.id.textView2);
                stringInfo2.setText(PostRunCurrentSensor);

                Button btnDismiss = popupView.findViewById(R.id.dismiss);
                btnDismiss.setOnClickListener(new Button.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        popupWindow.dismiss();
                    }
                });

                popupWindow.showAtLocation(rootView,0,0,0);
            }
        });
        //=========================================================================================
        TSPostRunAccelerator = rootView.findViewById(R.id.TSPostRunAccelerator);
        TSPostRunAccelerator.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                LayoutInflater layoutInflater
                        = (LayoutInflater) getContext()
                        .getSystemService(LAYOUT_INFLATER_SERVICE);
                View popupView = layoutInflater.inflate(R.layout.popup_window, null);
                final PopupWindow popupWindow = new PopupWindow(
                        popupView,
                        LayoutParams.WRAP_CONTENT,
                        LayoutParams.WRAP_CONTENT);
                String PostRunAccelerator = "===============ACCELERERATOR SHORTED=========="
                        + "\nPOST FAULT : Accelerator Shorted"
                        + "\nFAULT INDICATOR NUMBER OF BLINKS : 4"
                        + "\nFAULT DESCRIPTION : Accelerator input voltage is less than the value in EEPROM parameter,\n" +
                        "Pedal_Lo_EEPROM_(V)_x_100."
                        + "\n===================ACCELERERATOR OPENED======="
                        + "\nPOST FAULT :Accelerator Open"
                        + "\nFAULT INDICATOR NUMBER OF BLINKS : 4 "
                        + "\nFAULT DESCRIPTION : Accelerator input voltage is more than the value in EEPROM parameter,\n" +
                        "Pedal_Hi_EEPROM_(V)_x_100."
                        + "\n==============ACCELERATOR INPUT SHORTED FAULT=========="
                        + "\nRUN FAULT : Accelerator Input Shorted Fault"
                        + "\nFAULT INDICATOR NUMBER OF BLINKS :  4"
                        + "\nFAULT DESCRIPTION : Accelerator input is below the value in EEPROM parameter,\n" +
                        "Pedal_Lo_EEPROM_(V)_x_100."
                        + "\n================ACCELERATOR INPUT OPENED FAULT======="
                        + "\nRUN FAULT : Accelerator Input Open Fault"
                        + "\nFAULT INDICATOR NUMBER OF BLINKS : 4 "
                        + "\nFAULT DESCRIPTION : Accelerator input is above the value in EEPROM parameter,\n" +
                        "Pedal_Hi_EEPROM_(V)_x_100.";
                TextView stringInfo2 = popupView.findViewById(R.id.textView2);
                stringInfo2.setText(PostRunAccelerator);

                Button btnDismiss = popupView.findViewById(R.id.dismiss);
                btnDismiss.setOnClickListener(new Button.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        popupWindow.dismiss();
                    }
                });

                popupWindow.showAtLocation(rootView,0,0,0);
            }
        });
        //==========================================================================================
        TSPostRunTemperature = rootView.findViewById(R.id.TSPostRunTemperature);
        TSPostRunTemperature.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                LayoutInflater layoutInflater
                        = (LayoutInflater) getContext()
                        .getSystemService(LAYOUT_INFLATER_SERVICE);
                View popupView = layoutInflater.inflate(R.layout.popup_window, null);
                final PopupWindow popupWindow = new PopupWindow(
                        popupView,
                        LayoutParams.WRAP_CONTENT,
                        LayoutParams.WRAP_CONTENT);
                String PostRunTemperature = "===============MODULE TEMPERATURE LOW=============="
                        + "\nPOST FAULT : Module Temperature Low"
                        + "\nFAULT INDICATOR NUMBER OF BLINKS : 1"
                        + "\nFAULT DESCRIPTION :This fault is currently not active."
                        + "\n=====================MODULE TEMPERATURE HIGH============="
                        + "\nPOST FAULT : Module Temperature High"
                        + "\nFAULT INDICATOR NUMBER OF BLINKS : 1"
                        + "\nFAULT DESCRIPTION : One or more of the three module temperatures are above 125 C."
                        + "\n================CONTROL PCB TEMPERATURE LOW============="
                        + "\nPOST FAULT : Control PCB Temperature Low"
                        + "\nFAULT INDICATOR NUMBER OF BLINKS : 1"
                        + "\nFAULT DESCRIPTION : PCB temperature is below -24 C."
                        + "\n================CONTROL PCB TEMPERATURE HIGH============="
                        + "\nPOST FAULT : Control PCB Temperature High"
                        + "\nFAULT INDICATOR NUMBER OF BLINKS : 1"
                        + "\nFAULT DESCRIPTION : PCB temperature has exceeded 125 C."
                        + "\n=======================GATE DRIVE PCB TEMPERATURE LOW=========="
                        + "\nPOST FAULT : Gate Drive PCB Temperature Low"
                        + "\nFAULT INDICATOR NUMBER OF BLINKS : 1"
                        + "\nFAULT DESCRIPTION : GDB temperature is below -24 C."
                        + "\n=====================GATE DRIVE PCB TEMPERATURE HIGH==========="
                        + "\nPOST FAULT : Gate Drive PCB Temperature High"
                        + "\nFAULT INDICATOR NUMBER OF BLINKS : 1"
                        + "\nFAULT DESCRIPTION : GDB temperature has exceeded 125 C."
                        + "\n===================INVERTER RESPONSE TIME-OUT FAULT=========="
                        + "\nRUN FAULT : Inverter Over-temperature Fault"
                        + "\nFAULT INDICATOR NUMBER OF BLINKS : 1"
                        + "\nFAULT DESCRIPTION : One or more of the three module temperatures are above the value in EEPROM\n" +
                        "parameter, Inv_OverTemp_Limit_EEPROM_(C)_x_10."
                        + "\n===============MOTOR OVER-TEMPERATURE FAULT=============="
                        + "\nRUN FAULT : Motor Over-temperature Fault"
                        + "\nFAULT INDICATOR NUMBER OF BLINKS : 1"
                        + "\nFAULT DESCRIPTION :The motor temperature value exceeds the value in the EEPOM parameter,\n" +
                        "Mtr_OverTemp_Limit_EEPROM_(C)_x_10."
                        + "\n==============MODULE A OVER-TEMPERATURE FAULT============="
                        + "\nRUN FAULT : Module A Over-temperature Fault"
                        + "\nFAULT INDICATOR NUMBER OF BLINKS : 1"
                        + "\nFAULT DESCRIPTION : Module A temperature has exceeded the value in the EEPROM parameter,\n" +
                        "Inv_OverTemp_Limit_EEPROM_(C)_x_10.\n" +
                        "This is a new fault used only for Gen-3 boards (all RMS products are currently at Gen-3).";
                TextView stringInfo2 = popupView.findViewById(R.id.textView2);
                stringInfo2.setText(PostRunTemperature);
                String PostRunTemperature2 = "\n==========MODULE B OVER-TEMPERATURE FAULT============="
                        + "\nRUN FAULT : Module B Over-temperature Fault"
                        + "\nFAULT INDICATOR NUMBER OF BLINKS : 1"
                        + "\nFAULT DESCRIPTION : Module B temperature has exceeded the value in the EEPROM parameter,\n" +
                        "Inv_OverTemp_Limit_EEPROM_(C)_x_10.\n" +
                        "This is a new fault used only for Gen-3 boards (all RMS products are currently at Gen-3)."
                        + "\n===================MODULE C OVER-TEMPERATURE FAULT=========="
                        + "\nRUN FAULT : Module C Over-temperature Fault"
                        + "\nFAULT INDICATOR NUMBER OF BLINKS : 1"
                        + "\nFAULT DESCRIPTION : Module C temperature has exceeded the value in the EEPROM parameter,\n" +
                        "Inv_OverTemp_Limit_EEPROM_(C)_x_10.\n" +
                        "This is a new fault used only for Gen-3 boards (all RMS products are currently at Gen-3)."
                        + "\n=============PCB OVER-TEMPERATURE FAULT=========="
                        + "\nRUN FAULT : PCB Over-temperature Fault"
                        + "\nFAULT INDICATOR NUMBER OF BLINKS : 1"
                        + "\nFAULT DESCRIPTION : PCB temperature has exceeded the value in the EEPROM parameter,\n" +
                        "Inv_OverTemp_Limit_EEPROM_(C)_x_10.\n" +
                        "This is a new fault for Gen-3 boards only (all RMS products are currently at Gen-3)."
                        + "\n=============GATE DRIVE BOARD 1 OVER-TEMPERATURE FAULT==========="
                        + "\nRUN FAULT : Gate Drive Board 1 Over-temperature Fault"
                        + "\nFAULT INDICATOR NUMBER OF BLINKS : 1"
                        + "\nFAULT DESCRIPTION : GDB 1 temperature has exceeded the value in the EEPROM parameter,\n"
                        + "Inv_OverTemp_Limit_EEPROM_(C)_x_10."
                        + "\n==============GATE DRIVE BOARD 2 OVER-TEMPERATURE FAULT=========="
                        + "\nRUN FAULT : Gate Drive Board 2 Over-temperature Fault"
                        + "\nFAULT INDICATOR NUMBER OF BLINKS : 1"
                        + "\nFAULT DESCRIPTION : GDB 2 temperature has exceeded the value in the EEPROM parameter,\n" +
                        "Inv_OverTemp_Limit_EEPROM_(C)_x_10.\n" +
                        "This is a new fault for Gen-3 boards only (which is used in all PM150 units)."
                        + "\n===============GATE DRIVE BOARD 3 OVER-TEMPERATURE FAULT==========="
                        + "\nRUN FAULT : Gate Drive Board 3 Over-temperature Fault"
                        + "\nFAULT INDICATOR NUMBER OF BLINKS : 1"
                        + "\nFAULT DESCRIPTION : GDB 3 temperature has exceeded the value in the EEPROM parameter,\n"
                        + "Inv_OverTemp_Limit_EEPROM_(C)_x_10.\n" +
                        "This is a new fault for Gen-3 boards only (which is used in all PM150 units).";
                TextView stringInfo3 = popupView.findViewById(R.id.textView3);
                stringInfo3.setText(PostRunTemperature2);

                Button btnDismiss = popupView.findViewById(R.id.dismiss);
                btnDismiss.setOnClickListener(new Button.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        popupWindow.dismiss();
                    }
                });

                popupWindow.showAtLocation(rootView,0,0,0);
            }
        });
        //==========================================================================================
        TSPostRunVoltageSensor = rootView.findViewById(R.id.TSPostRunVoltageSensor);
        TSPostRunVoltageSensor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                LayoutInflater layoutInflater
                        = (LayoutInflater) getContext()
                        .getSystemService(LAYOUT_INFLATER_SERVICE);
                View popupView = layoutInflater.inflate(R.layout.popup_window, null);
                final PopupWindow popupWindow = new PopupWindow(
                        popupView,
                        LayoutParams.WRAP_CONTENT,
                        LayoutParams.WRAP_CONTENT);
                String PostRunVoltageSensor = "===============5V SENSE VOLTAGE LOW=============="
                        + "\nPOST FAULT : 5V Sense Voltage Low"
                        + "\nFAULT INDICATOR NUMBER OF BLINKS : 2"
                        + "\nFAULT DESCRIPTION :5V Sense reading is too low."
                        + "\n=================5V SENSE VOLTAGE HIGH============="
                        + "\nPOST FAULT : 5V Sense Voltage High"
                        + "\nFAULT INDICATOR NUMBER OF BLINKS : 2"
                        + "\nFAULT DESCRIPTION : 5V Sense reading is too high."
                        + "\n===================12V SENSE VOLTAGE LOW============="
                        + "\nPOST FAULT : 12V Sense Voltage Low"
                        + "\nFAULT INDICATOR NUMBER OF BLINKS : 2"
                        + "\nFAULT DESCRIPTION : 12V Sense reading is too low."
                        + "\n==================12V SENSE VOLTAGE HIGH============"
                        + "\nPOST FAULT : 12V Sense Voltage High"
                        + "\nFAULT INDICATOR NUMBER OF BLINKS : 2"
                        + "\nFAULT DESCRIPTION : 12V Sense reading is too high."
                        + "\n==================2.5V SENSE VOLTAGE LOW=========="
                        + "\nPOST FAULT : 2.5V Sense Voltage Low"
                        + "\nFAULT INDICATOR NUMBER OF BLINKS : 2"
                        + "\nFAULT DESCRIPTION : 2.5V Sense reading is too low."
                        + "\n================2.5V SENSE VOLTAGE HIGH==========="
                        + "\nPOST FAULT : 2.5V Sense Voltage High"
                        + "\nFAULT INDICATOR NUMBER OF BLINKS : 2"
                        + "\nFAULT DESCRIPTION : 2.5V Sense reading is too high."
                        + "\n===================1.5V SENSE VOLTAGE LOW=========="
                        + "\nPOST FAULT : 1.5V Sense Voltage Low"
                        + "\nFAULT INDICATOR NUMBER OF BLINKS : 2"
                        + "\nFAULT DESCRIPTION : 1.5V Sense reading is too low."
                        + "\n===============1.5V SENSE VOLTAGE HIGH==========="
                        + "\nPOST FAULT : 1.5V Sense Voltage High"
                        + "\nFAULT INDICATOR NUMBER OF BLINKS : 2"
                        + "\nFAULT DESCRIPTION : 1.5V Sense reading is too high."
                        + "\n==============OVER-VOLTAGE FAULT================"
                        + "\nRUN FAULT : Over-voltage Fault"
                        + "\nFAULT INDICATOR NUMBER OF BLINKS : 2"
                        + "\nFAULT DESCRIPTION : Filtered value of DC voltage is above the hard-coded SW over-voltage limit. SW"
                        + "\nover-voltage limit can be checked from the monitored parameter list by adding"
                        + "\nSW_Over_Voltage_(Volts)_x_10 to the watch list."
                        + "\n================UNDER-VOLTAGE FAULT================"
                        + "\nRUN FAULT : Under-voltage Fault"
                        + "\nFAULT INDICATOR NUMBER OF BLINKS : 2"
                        + "\nFAULT DESCRIPTION : DC bus voltage is below the value in EEPROM parameter,\n" +
                        "DC_UnderVolt_Thresh_EEPROM_(V)_x_10.";
                TextView stringInfo2 = popupView.findViewById(R.id.textView2);
                stringInfo2.setText(PostRunVoltageSensor);

                Button btnDismiss = popupView.findViewById(R.id.dismiss);
                btnDismiss.setOnClickListener(new Button.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        popupWindow.dismiss();
                    }
                });

                popupWindow.showAtLocation(rootView,0,0,0);
            }
        });
        //==========================================================================================
        TSPostRunPreCharge = rootView.findViewById(R.id.TSPostRunPreCharge);
        TSPostRunPreCharge.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                LayoutInflater layoutInflater
                        = (LayoutInflater) getContext()
                        .getSystemService(LAYOUT_INFLATER_SERVICE);
                View popupView = layoutInflater.inflate(R.layout.popup_window, null);
                final PopupWindow popupWindow = new PopupWindow(
                        popupView,
                        LayoutParams.WRAP_CONTENT,
                        LayoutParams.WRAP_CONTENT);
                String PostRunPreCharge = "================DC BUS VOLTAGE HIGH==============="
                        + "\nPOST FAULT : DC Bus Voltage High"
                        + "\nFAULT INDICATOR NUMBER OF BLINKS : 6"
                        + "\nFAULT DESCRIPTION : During pre-charge, DC voltage is above the hard-coded SW over-voltage limit.\n" +
                        "SW over-voltage limit can be checked from the monitored parameter list by\n" +
                        "adding SW_Over_Voltage_(Volts)_x_10."
                        +"\n=====================DC BUS VOLTAGE LOW============="
                        + "\nPOST FAULT : DC Bus Voltage Low"
                        + "\nFAULT INDICATOR NUMBER OF BLINKS : 6"
                        + "\nFAULT DESCRIPTION : DC bus voltage is below 100-V."
                        + "\n==================PRE-CHARGE TIMEOUT==============="
                        + "\nPOST FAULT : Pre-charge Timeouth"
                        + "\nFAULT INDICATOR NUMBER OF BLINKS : 6"
                        + "\nFAULT DESCRIPTION : DC bus voltage is not charging at the rate of 2.7 V/50 msec and 3 seconds have\n" +
                        "elapsed."
                        +"\n============PRE-CHARGE VOLTAGE FAILURE============="
                        + "\nPOST FAULT : Pre-charge Voltage Failure"
                        + "\nFAULT INDICATOR NUMBER OF BLINKS : 6"
                        + "\nFAULT DESCRIPTION : After pre-charge is complete, DC voltage has changed by more than 10-V within\n" +
                        "15 msec."
                        +"\n====================MOTOR OVER-SPEED FAULT============="
                        + "\nRUN FAULT : Motor Over-speed Fault"
                        + "\nFAULT INDICATOR NUMBER OF BLINKS : 6"
                        + "\nFAULT DESCRIPTION : Motor speed is above the value in EEPROM parameter,\n" +
                        "Motor_Overspeed_EEPROM_(RPM).";
                TextView stringInfo2 = popupView.findViewById(R.id.textView2);
                stringInfo2.setText(PostRunPreCharge);

                Button btnDismiss = popupView.findViewById(R.id.dismiss);
                btnDismiss.setOnClickListener(new Button.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        popupWindow.dismiss();
                    }
                });

                popupWindow.showAtLocation(rootView,0,0,0);
            }
        });
        //==========================================================================================
        TSPostRunEEPROM = rootView.findViewById(R.id.TSPostRunEEPROM);
        TSPostRunEEPROM.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                LayoutInflater layoutInflater
                        = (LayoutInflater) getContext()
                        .getSystemService(LAYOUT_INFLATER_SERVICE);
                View popupView = layoutInflater.inflate(R.layout.popup_window, null);
                final PopupWindow popupWindow = new PopupWindow(
                        popupView,
                        LayoutParams.WRAP_CONTENT,
                        LayoutParams.WRAP_CONTENT);

                TextView stringInfo2 = popupView.findViewById(R.id.textView2);
                String PostRunEEPRROM = "==================EEPROM CHECKSUM INVALID==============="
                        + "\nPOST FAULT : EEPROM Checksum Invalid"
                        + "\nFAULT INDICATOR NUMBER OF BLINKS : 7"
                        + "\nFAULT DESCRIPTION : EEPROM checksum is not valid."
                        +"\n============EEPROM DATA OUT OF RANGE============="
                        + "\nPOST FAULT : EEPROM Data Out of Range"
                        + "\nFAULT INDICATOR NUMBER OF BLINKS : 7"
                        + "\nFAULT DESCRIPTION :This fault is currently not active."
                        +"\n=================EEPROM UPDATE REQUIRED==============="
                        + "\nPOST FAULT : EEPROM Update Required"
                        + "\nFAULT INDICATOR NUMBER OF BLINKS : 7"
                        + "\nFAULT DESCRIPTION : The number of EEPROM parameters has changed (most of the time increased), "
                        + "check the new parameters and set appropriate values."
                        + "\n=================DIRECTION COMMAND FAULT==============="
                        + "\nRUN FAULT : Direction Command Fault"
                        + "\nFAULT INDICATOR NUMBER OF BLINKS : 7"
                        + "\nFAULT DESCRIPTION : Both directions forward and reverse are active at the same time.\n" +
                        "This fault has been de-activated.";
                stringInfo2.setText(PostRunEEPRROM);

                Button btnDismiss = popupView.findViewById(R.id.dismiss);
                btnDismiss.setOnClickListener(new Button.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        popupWindow.dismiss();
                    }
                });

                popupWindow.showAtLocation(rootView,0,0,0);
            }
        });
        //==========================================================================================
        TSPostRunBrake = rootView.findViewById(R.id.TSPostRunBrake);
        TSPostRunBrake.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                LayoutInflater layoutInflater
                        = (LayoutInflater) getContext()
                        .getSystemService(LAYOUT_INFLATER_SERVICE);
                View popupView = layoutInflater.inflate(R.layout.popup_window, null);
                final PopupWindow popupWindow = new PopupWindow(
                        popupView,
                        LayoutParams.WRAP_CONTENT,
                        LayoutParams.WRAP_CONTENT);


                TextView stringInfo2 = popupView.findViewById(R.id.textView2);
                String PostRunBrake = "=============BRAKE SHORTED==============="
                        + "\nPOST FAULT : Brake Shorted"
                        + "\nFAULT INDICATOR NUMBER OF BLINKS : 8"
                        + "\nFAULT DESCRIPTION : Brake input voltage is less than the value in EEPROM parameter,\n" +
                        "Brake_Lo_EEPROM_(V)_x_100."
                        +"\n================BRAKE OPEN============="
                        + "\nPOST FAULT : Brake Open"
                        + "\nFAULT INDICATOR NUMBER OF BLINKS : 8"
                        + "\nFAULT DESCRIPTION : Brake input voltage is more than the value in EEPROM parameter,\n" +
                        "Brake_Hi_EEPROM_(V)_x_100."
                        +"\n=================INVERTER RESPONSE TIME-OUT FAULT========="
                        + "\nRUN FAULT : Inverter Response Time-out Fault"
                        + "\nFAULT INDICATOR NUMBER OF BLINKS : 8"
                        + "\nFAULT DESCRIPTION : Inverter has not been enabled within 2 minutes of receiving the inverter enable"
                        + "\ncommand either through VSM or CAN.";
                stringInfo2.setText(PostRunBrake);

                Button btnDismiss = popupView.findViewById(R.id.dismiss);
                btnDismiss.setOnClickListener(new Button.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        popupWindow.dismiss();
                    }
                });
                popupWindow.showAtLocation(rootView,0,0,0);
            }
        });
        //=========================================================================================
        TSRunCan = rootView.findViewById(R.id.TSRunCan);
        TSRunCan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                LayoutInflater layoutInflater
                        = (LayoutInflater) getContext()
                        .getSystemService(LAYOUT_INFLATER_SERVICE);
                View popupView = layoutInflater.inflate(R.layout.popup_window, null);
                final PopupWindow popupWindow = new PopupWindow(
                        popupView,
                        LayoutParams.WRAP_CONTENT,
                        LayoutParams.WRAP_CONTENT);

                TextView stringInfo2 = popupView.findViewById(R.id.textView2);
                String RunCan = "============CAN COMMAND MESSAGE LOST FAULT==============="
                        + "\nRUN FAULT : CAN Command Message Lost Fault"
                        + "\nFAULT INDICATOR NUMBER OF BLINKS : 9"
                        + "\nFAULT DESCRIPTION : The inverter is not able to see the heartbeat command message when in CAN\n" +
                        "mode.";
                stringInfo2.setText(RunCan);

                Button btnDismiss = popupView.findViewById(R.id.dismiss);
                btnDismiss.setOnClickListener(new Button.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        popupWindow.dismiss();
                    }
                });

                popupWindow.showAtLocation(rootView,0,0,0);
            }
        });
        //=========================================================================================
        TSRunBrake = rootView.findViewById(R.id.TSRunBrake);
        TSRunBrake.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                LayoutInflater layoutInflater
                        = (LayoutInflater) getContext()
                        .getSystemService(LAYOUT_INFLATER_SERVICE);
                View popupView = layoutInflater.inflate(R.layout.popup_window, null);
                final PopupWindow popupWindow = new PopupWindow(
                        popupView,
                        LayoutParams.WRAP_CONTENT,
                        LayoutParams.WRAP_CONTENT);

                TextView stringInfo2 = popupView.findViewById(R.id.textView2);
                String RunBrake = "=============BRAKE INPUT SHORTED FAULT==============="
                        + "\nRUN FAULT : Brake Input Shorted Fault"
                        + "\nFAULT INDICATOR NUMBER OF BLINKS : 10"
                        + "\nFAULT DESCRIPTION : Brake input is below the value in EEPROM parameter, Brake_Lo_EEPROM_(V)_x_100."
                        + "\n===================BRAKE INPUT OPEN FAULT============="
                        + "\nRUN FAULT : Brake Input Open Fault"
                        + "\nFAULT INDICATOR NUMBER OF BLINKS : 10"
                        + "\nFAULT DESCRIPTION : Brake input is above the value in EEPROM parameter, Brake_Hi_EEPROM_(V)_x_100.";
                stringInfo2.setText(RunBrake);
                Button btnDismiss = popupView.findViewById(R.id.dismiss);
                btnDismiss.setOnClickListener(new Button.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        popupWindow.dismiss();
                    }
                });
                popupWindow.showAtLocation(rootView,0,0,0);
            }
        });

        //=========================================================================================
        TSRunDisCharge = rootView.findViewById(R.id.TSRunDisCharge);
        TSRunDisCharge.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                LayoutInflater layoutInflater
                        = (LayoutInflater) getContext()
                        .getSystemService(LAYOUT_INFLATER_SERVICE);
                View popupView = layoutInflater.inflate(R.layout.popup_window, null);
                final PopupWindow popupWindow = new PopupWindow(
                        popupView,
                        LayoutParams.WRAP_CONTENT,
                        LayoutParams.WRAP_CONTENT);

                TextView stringInfo2 = popupView.findViewById(R.id.textView2);
                String RunDischarge = "==========RESOLVER NOT CONNECTED FAULT==============="
                        + "\nPOST FAULT : Resolver Not Connected Fault"
                        + "\nFAULT INDICATOR NUMBER OF BLINKS : 11"
                        + "\nFAULT DESCRIPTION : The resolver is not connected."
                        + "\n================INVERTER DISCHARGE ACTIVE============="
                        + "\nPOST FAULT : Inverter Discharge Active"
                        + "\nFAULT INDICATOR NUMBER OF BLINKS : 11"
                        + "\nFAULT DESCRIPTION : Inverter discharge is in process.";
                stringInfo2.setText(RunDischarge);

                Button btnDismiss = popupView.findViewById(R.id.dismiss);
                btnDismiss.setOnClickListener(new Button.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        popupWindow.dismiss();
                    }
                });

                popupWindow.showAtLocation(rootView,0,0,0);
            }
        });
        //=========================================================================================

        return rootView;
    }


    public void Faults(Button fault, Boolean check) {

        if(check == true) {
            fault.setBackgroundColor(0xA4FFEB3B);//change to yellow if fault
        } else {
            fault.setBackgroundColor(0xAE00FF03);//change to green if fault
        }
    }



//=================================================================================================
//Ignore this method....
    @Override
    public void onClick(View view) {
        LayoutInflater layoutInflater
                = (LayoutInflater) getContext()
                .getSystemService(LAYOUT_INFLATER_SERVICE);
        View popupView = layoutInflater.inflate(R.layout.popup_window, null);
        final PopupWindow popupWindow = new PopupWindow(
                popupView,
                LayoutParams.WRAP_CONTENT,
                LayoutParams.WRAP_CONTENT);

        Button btnDismiss =  popupView.findViewById(R.id.dismiss);
        btnDismiss.setOnClickListener(new Button.OnClickListener() {

            @Override
            public void onClick(View v) {
                popupWindow.dismiss();
            }
        });

    }
//================================================================================================


}