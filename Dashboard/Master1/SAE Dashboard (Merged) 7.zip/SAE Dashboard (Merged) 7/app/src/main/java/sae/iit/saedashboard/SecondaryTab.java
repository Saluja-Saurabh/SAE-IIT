package sae.iit.saedashboard;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import java.util.List;
import java.util.ArrayList;
import android.widget.ListView;
import android.widget.ArrayAdapter;
import androidx.fragment.app.Fragment;

/*Designer: Deep Trapasia
SAE Electrical Team Member(Software Team) 2019-2020
 */

public class SecondaryTab extends Fragment {
    //======================================
    //BMS(Battery Management System) datalogging variables
    double BMSbatteryVoltage;
    double BMSBatteryTemp;
    double BMSPowerUsage;
    double BMSAverageSpeed;
    double BMSActiveAeroPosition;
    //Left Motor Data logging variables
    double LeftMotorTemp;
    double LeftMotorPhaseATemp;
    double LeftMotorPhaseBTemp;
    double LeftMotorPhaseCTemp;
    double LeftMotorPhaseACurrent;
    double LeftMotorPhaseBCurrent;
    double LeftMotorPhaseCCurrent;
    double LeftMotorDCBusCurrent;

    //Right Motor Data logging variables
    double RightMotorTemp;
    double RightMotorPhaseATemp;
    double RightMotorPhaseBTemp;
    double RightMotorPhaseCTemp;
    double RightMotorPhaseACurrent;
    double RightMotorPhaseBCurrent;
    double  RightMotorPhaseCCurrent;
    double  RightMotorDCBusCurrent;
    //============================
    //BMS datalogging
    String [] BMSaddress1;
    String [] BMSaddress2;
    String [] BMSaddress10;
    String [] BMSaddress4;
    String [] BMSaddress5;

    //Left Motor Data logging
    String [] LeftMotorAddress3;
    String [] LeftMotorAddress6;
    String [] LeftMotorAddress7;
    String [] LeftMotorAddress8;
    String [] LeftMotorAddress9;
    String [] LeftMotorAddress11;
    String [] LeftMotorAddress12;
    String [] LeftMotorAddress13;
    String [] LeftMotorAddress14;

    //Right Motor Data logging
    String [] RightMotorAddress15;
    String [] RightMotorAddress16;
    String [] RightMotorAddress17;
    String [] RightMotorAddress18;
    String [] RightMotorAddress19;
    String [] RightMotorAddress20;
    String [] RightMotorAddress21;
    String [] RightMotorAddress22;
    String [] RightMotorAddress23;
    //============================

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState){
        ViewGroup rootView = (ViewGroup) inflater.inflate(R.layout.secondary_tab, container, false);


        //======================================================================================================================
        //CSV file will datalog all these addresses
        //BMS datalogging
        BMSaddress1 = new String[]{" -- Battery Voltage -- ", Double.toString(BMSbatteryVoltage), " Volts"};
        BMSaddress2 = new String[]{" -- Battery Temp -- ", Double.toString(BMSBatteryTemp), " F"};
        BMSaddress10 = new String[]{" -- Active Aeronautical Position -- ", Double.toString(BMSActiveAeroPosition), " Degrees"};
        BMSaddress4 = new String[]{" -- Power Usage -- ", Double.toString(BMSPowerUsage), " %"};
        BMSaddress5 = new String[]{" -- Average Speed -- ", Double.toString(BMSAverageSpeed), " mph"};

        //Left Motor Data logging
        LeftMotorAddress3 = new String[]{" -- Left Motor Temp -- ", Double.toString(LeftMotorTemp), " F"};
        LeftMotorAddress7 = new String[]{" -- Left Motor Temp Phase A Temp -- ", Double.toString(LeftMotorPhaseATemp), " F"};
        LeftMotorAddress8 = new String[]{" -- Left Motor Temp Phase B Temp -- ", Double.toString(LeftMotorPhaseBTemp), " F"};
        LeftMotorAddress9 = new String[]{" -- Left Motor Temp Phase C Temp -- ", Double.toString(LeftMotorPhaseCTemp), " F"};
        LeftMotorAddress11 = new String[]{" -- Left Motor Temp Phase A Current -- ", Double.toString(LeftMotorPhaseACurrent), " Amps"};
        LeftMotorAddress12 = new String[]{" -- Left Motor Temp Phase B Current -- ", Double.toString(LeftMotorPhaseBCurrent), " Amps"};
        LeftMotorAddress13 = new String[]{" -- Left Motor Temp Phase C Current -- ", Double.toString(LeftMotorPhaseCCurrent), " Amps"};
        LeftMotorAddress14 = new String[]{" -- Left Motor Temp DC Bus Current -- ", Double.toString(LeftMotorDCBusCurrent), "  Amps"};

        //Right Motor Data logging
        RightMotorAddress15 = new String[]{" -- Right Motor Temp -- ", Double.toString(RightMotorTemp), " F"};
        RightMotorAddress17 = new String[]{" -- Right Motor Phase A Temp -- ", Double.toString(RightMotorPhaseATemp), " F"};
        RightMotorAddress18 = new String[]{" -- Right Motor Phase B Temp -- ", Double.toString(RightMotorPhaseBTemp), " F"};
        RightMotorAddress19 = new String[]{" -- Right Motor Phase C Temp -- ", Double.toString(RightMotorPhaseCTemp), " F"};
        RightMotorAddress20 = new String[]{" -- Right Motor Phase A Current -- ", Double.toString(RightMotorPhaseACurrent), " Amps"};
        RightMotorAddress21 = new String[]{" -- Right Motor Phase B Current -- ", Double.toString(RightMotorPhaseBCurrent), " Amps"};
        RightMotorAddress22 = new String[]{" -- Right Motor Phase C Current -- ", Double.toString(RightMotorPhaseCCurrent), " Amps"};
        RightMotorAddress23 = new String[]{" -- Right Motor DC Bus Current -- ", Double.toString(RightMotorDCBusCurrent), "  Amps"};
        //===========================================================================================================================

        String add1 = BMSaddress1[0] + "                 " +  BMSaddress1[1] + " " +  BMSaddress1[2];
        String add2 = BMSaddress2[0] + "                 " +  BMSaddress2[1] + " " +  BMSaddress2[2];
        String add3 = LeftMotorAddress3[0] + "                 " + LeftMotorAddress3[1] + " " + LeftMotorAddress3[2];
        String add4 = BMSaddress4[0] + "                 " + BMSaddress4[1] + " " + BMSaddress4[2];
        String add5 = BMSaddress5[0] + "                 " + BMSaddress5[1] + " " + BMSaddress5[2];
        String add7 = LeftMotorAddress7[0] + "                 " +  LeftMotorAddress7 [1] + " " +  LeftMotorAddress7[2];
        String add8 = LeftMotorAddress8[0] + "                 " + LeftMotorAddress8[1] + " " + LeftMotorAddress8[2];
        String add9 = LeftMotorAddress9[0] + "                 " + LeftMotorAddress9[1] + " " + LeftMotorAddress9[2];
        String add10 = BMSaddress10[0] + "                 " + BMSaddress10[1] + " " + BMSaddress10[2];
        String add11 = LeftMotorAddress11[0] + "                 " + LeftMotorAddress11[1] + " " + LeftMotorAddress11[2];
        String add12 = LeftMotorAddress12[0] + "                 " + LeftMotorAddress12[1] + " " + LeftMotorAddress12[2];
        String add13 = LeftMotorAddress13[0] + "                 " + LeftMotorAddress13[1] + " " +LeftMotorAddress13[2];
        String add14 = LeftMotorAddress14[0] + "                 " + LeftMotorAddress14[1] + " " + LeftMotorAddress14[2];
        String add15 = RightMotorAddress15[0] + "                 " + RightMotorAddress15[1] + " " + RightMotorAddress15[2];
        String add17 = RightMotorAddress17[0] + "                 " + RightMotorAddress17[1] + " " + RightMotorAddress17[2];
        String add18 = RightMotorAddress18[0] + "                 " + RightMotorAddress18[1] + " " + RightMotorAddress18[2];
        String add19 = RightMotorAddress19[0] + "                 " + RightMotorAddress19[1] + " " + RightMotorAddress19[2];
        String add20 = RightMotorAddress20[0] + "                 " + RightMotorAddress20[1] + " " +RightMotorAddress20[2];
        String add21 = RightMotorAddress21[0] + "                 " +  RightMotorAddress21[1] + " " +  RightMotorAddress21[2];
        String add22 = RightMotorAddress22[0] + "                 " + RightMotorAddress22[1] + " " + RightMotorAddress22[2];
        String add23 = RightMotorAddress23[0] + "                 " + RightMotorAddress23[1] + " " + RightMotorAddress23[2];
        //=====================================================================================
        //Left motor datalogger
        ListView t1 = rootView.findViewById(R.id.simpleListView1);
        List<String> list1 = new ArrayList<String>();

        list1.add(add3);
        list1.add(add11);
        list1.add(add12);
        list1.add(add13);
        list1.add(add14);
        list1.add(add7);
        list1.add(add8);
        list1.add(add9);

        //Right motor datalogger
        ListView t2 = rootView.findViewById(R.id.simpleListView2);
        List<String> list2 = new ArrayList<String>();

        list2.add(add15);
        list2.add(add17);
        list2.add(add18);
        list2.add(add19);
        list2.add(add20);
        list2.add(add21);
        list2.add(add22);
        list2.add(add23);


        //BMS (Battery Management System) datalogger
        ListView t3 = rootView.findViewById(R.id.simpleListView3);
        List<String> list3 = new ArrayList<String>();

        list3.add(add1);
        list3.add(add2);
        list3.add(add4);
        list3.add(add5);
        list3.add(add10);

        //Left motor data List Maker (rowed)
        ArrayAdapter<String> arrayAdapter1 = new ArrayAdapter<String>(getActivity(), R.layout.rows, list1);
        t1.setAdapter(arrayAdapter1);
        //Right motor data List Maker (rowed)
        ArrayAdapter<String> arrayAdapter2 = new ArrayAdapter<String>(getActivity(), R.layout.rows, list2);
        t2.setAdapter(arrayAdapter2);
        //BMS (Battery Management System) List Maker (rowed)
        ArrayAdapter<String> arrayAdapter3 = new ArrayAdapter<String>(getActivity(), R.layout.rows, list3);
        t3.setAdapter(arrayAdapter3);

        //=======================================================================================


        return rootView;
    }
    //===============================BMS Setters (Battery Management System)===================
    public void setBMSBatteryVoltage(double voltage) {
        this.BMSbatteryVoltage = voltage;
        BMSaddress1[1] = Double.toString(BMSbatteryVoltage);
    }
    public void setBMSBatteryTemp(double temp) {
        this.BMSBatteryTemp = temp;
        BMSaddress2[1] = Double.toString(BMSBatteryTemp);
    }
    public void setBMSPowerUsage(double BatteryVolts, double BatteryCurrent) {
        double powerUsage = BatteryCurrent*BatteryVolts;
        this.BMSPowerUsage = powerUsage;
        BMSaddress4[1] = Double.toString(BMSPowerUsage);
    }

    public void setBMSAverageSpeed(double averageSpeed) {
        this.BMSAverageSpeed = averageSpeed;
        BMSaddress5[1] = Double.toString(BMSAverageSpeed);
    }
    public void setBMSActiveAeroPosition(double degrees) {
        this.BMSActiveAeroPosition = degrees;
        BMSaddress10[1] = Double.toString(BMSActiveAeroPosition);
    }

    // ================================Left Motor Controller Setters============================

    public void setLeftMotorTemp(double temp) {
        this.LeftMotorTemp = temp;
        LeftMotorAddress3[1] = Double.toString(LeftMotorTemp);
    }

    public void setLeftMotorPhaseATemp(double temp) {
        this.LeftMotorPhaseATemp = temp;
        LeftMotorAddress7[1] = Double.toString(LeftMotorPhaseATemp);
    }

    public void setLeftMotorPhaseBTemp(double temp) {
        this.LeftMotorPhaseBTemp = temp;
        LeftMotorAddress8[1] = Double.toString(LeftMotorPhaseBTemp);
    }

    public void setLeftMotorPhaseCTemp(double temp) {
        this.LeftMotorPhaseCTemp = temp;
        LeftMotorAddress9[1] = Double.toString(LeftMotorPhaseCTemp);
    }

    public void setLeftMotorPhaseACurrent(double amps) {
        this.LeftMotorPhaseACurrent = amps;
        LeftMotorAddress11[1] = Double.toString(LeftMotorPhaseACurrent);
    }

    public void setLeftMotorPhaseBCurrent(double amps) {
        this.LeftMotorPhaseBCurrent = amps;
        LeftMotorAddress12[1] = Double.toString(LeftMotorPhaseBCurrent);
    }
    public void setLeftMotorPhaseCCurrent(double amps) {
        this.LeftMotorPhaseCCurrent = amps;
        LeftMotorAddress13[1] = Double.toString(LeftMotorPhaseCCurrent);
    }
    public void setLeftMotorDCBusCurrent(double amps) {
        this.LeftMotorDCBusCurrent = amps;
        LeftMotorAddress14[1] = Double.toString(LeftMotorDCBusCurrent);
    }

    //===============Right Motor Controller setters================================

    public void setRightMotorPhaseATemp(double temp) {
        this.RightMotorPhaseATemp = temp;
        RightMotorAddress17[1] =Double.toString(RightMotorPhaseATemp);
    }

    public void setRightMotorPhaseBTemp(double temp) {
        this.RightMotorPhaseBTemp = temp;
        RightMotorAddress21[1] = Double.toString(RightMotorPhaseBTemp);
    }

    public void setRightMotorPhaseCTemp(double temp) {
        this.RightMotorPhaseCTemp = temp;
        RightMotorAddress19[1] = Double.toString(RightMotorPhaseCTemp);
    }
    public void setRightMotorDCBusCurrent(double amps) {
        this.RightMotorDCBusCurrent = amps;
        RightMotorAddress23[1] = Double.toString(RightMotorDCBusCurrent);
    }
    public void setRightMotorPhaseACurrent(double amps) {
        this.RightMotorPhaseACurrent = amps;
        RightMotorAddress20[1] = Double.toString(RightMotorPhaseACurrent);
    }

    public void setRightMotorPhaseBCurrent(double amps) {
        this.RightMotorPhaseBCurrent = amps;
        RightMotorAddress21[1] = Double.toString(RightMotorPhaseBCurrent);
    }
    public void setRightMotorPhaseCCurrent(double amps) {
        this.RightMotorPhaseCCurrent = amps;
        RightMotorAddress22[1] = Double.toString(RightMotorPhaseCCurrent);
    }
    public void setRightMotorTemp(double temp) {
        this.RightMotorTemp = temp;
        RightMotorAddress15[1] = Double.toString(RightMotorTemp);
    }

}
