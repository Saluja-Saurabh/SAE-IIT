package sae.iit.saedashboard;

import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.fragment.app.Fragment;

import com.sccomponents.gauges.library.ScArcGauge;
import com.sccomponents.gauges.library.ScFeature;
import com.sccomponents.gauges.library.ScGauge;
import com.sccomponents.gauges.library.ScNotches;

public class TroubleshootTab extends Fragment {

    //Creates a view that is compatible with ViewPager
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        ViewGroup rootView = (ViewGroup) inflater.inflate(
                R.layout.troubleshoot_tab, container, false);
        //Test gauge
        final ScArcGauge gauge = rootView.findViewById(R.id.gauge);
        assert gauge != null;

        final TextView counter = rootView.findViewById(R.id.counter);
        assert counter != null;

        // Clear all default features from the gauge
        gauge.removeAllFeatures();

        // Create the base notches.
        ScNotches base = (ScNotches) gauge.addFeature(ScNotches.class);
        base.setTag(ScGauge.BASE_IDENTIFIER);
        base.setPosition(ScFeature.Positions.INSIDE);
        base.setRepetitions(40);
        base.setWidths(10);
        base.setHeights(10, 120);
        base.setColors(Color.parseColor("#dbdfe6"));

        // Create the progress notches.
        ScNotches progress = (ScNotches) gauge.addFeature(ScNotches.class);
        progress.setTag(ScGauge.PROGRESS_IDENTIFIER);
        progress.setColors(
                Color.parseColor("#0BA60A"),
                Color.parseColor("#FEF301"),
                Color.parseColor("#EA0C01")
        );

        // Set the value
        gauge.setHighValue(12000, 0, 13000);

        // Each time I will change the value I must write it inside the counter text.
        gauge.setOnEventListener(new ScGauge.OnEventListener() {
            @Override
            public void onValueChange(ScGauge gauge, float lowValue, float highValue, boolean isRunning) {

            }

        });
        return rootView;
    }

}
