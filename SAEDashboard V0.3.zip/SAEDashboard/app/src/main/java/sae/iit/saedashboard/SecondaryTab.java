package sae.iit.saedashboard;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.fragment.app.Fragment;

public class SecondaryTab extends Fragment {

    TextView batteryVoltage;
    TextView batteryTemp;
    TextView ampsPulled;
    TextView motorTemp;


    //Creates a view that is compatible with ViewPager
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        ViewGroup rootView = (ViewGroup) inflater.inflate(
                R.layout.secondary_tab, container, false);
        //Initializing fields
        batteryVoltage = rootView.findViewById(R.id.batteryVoltage);
        batteryTemp = rootView.findViewById(R.id.batteryTemp);
        ampsPulled = rootView.findViewById(R.id.powerUsageAmp);
        motorTemp = rootView.findViewById(R.id.motorTemp);
        return rootView;
    }

    //Updates info fields
    public void setBatteryVoltage(double voltage) {
        batteryVoltage.setText(String.valueOf(voltage));
    }

    public void setBatteryTemp(double temp) {
        batteryTemp.setText(String.valueOf(temp));
    }

    public void setAmpsPulled(double amps) {
        ampsPulled.setText(String.valueOf(amps));
    }

    public void setMotorTemp(double temp) {
        motorTemp.setText(String.valueOf(temp));
    }

}
