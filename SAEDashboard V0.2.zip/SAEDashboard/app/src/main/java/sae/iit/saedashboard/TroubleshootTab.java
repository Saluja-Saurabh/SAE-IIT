package sae.iit.saedashboard;

import android.graphics.BlurMaskFilter;
import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.fragment.app.Fragment;

import com.sccomponents.gauges.library.ScArcGauge;
import com.sccomponents.gauges.library.ScCopier;
import com.sccomponents.gauges.library.ScFeature;
import com.sccomponents.gauges.library.ScGauge;
import com.sccomponents.gauges.library.ScNotches;
import com.sccomponents.gauges.library.ScPointer;
import com.sccomponents.gauges.library.ScRepetitions;
import com.sccomponents.gauges.library.ScWriter;

public class TroubleshootTab extends Fragment {

    //Creates a view that is compatible with ViewPager
    @Override
    public View onCreateView(final LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        ViewGroup rootView = (ViewGroup) inflater.inflate(
                R.layout.troubleshoot_tab, container, false);
        //Test
        Button button = rootView.findViewById(R.id.button);
        final TextView input = rootView.findViewById(R.id.editText);

        final ScArcGauge gauge = (ScArcGauge) rootView.findViewById(R.id.gauge);
        assert gauge != null;

        final TextView counter = (TextView) rootView.findViewById(R.id.counter);
        assert counter != null;

        // Clear all default features from the gauge
        gauge.removeAllFeatures();

        // Create the base notches.
        ScNotches base = (ScNotches) gauge.addFeature(ScNotches.class);
        base.setTag(ScGauge.BASE_IDENTIFIER);
        base.setPosition(ScFeature.Positions.INSIDE);
        base.setRepetitions(40);
        base.setWidths(10);
        base.setHeights(10, 120);
        base.setColors(Color.parseColor("#dbdfe6"));

        // Create the progress notches.
        ScNotches progress = (ScNotches) gauge.addFeature(ScNotches.class);
        progress.setTag(ScGauge.PROGRESS_IDENTIFIER);
        progress.setColors(
                Color.parseColor("#0BA60A"),
                Color.parseColor("#FEF301"),
                Color.parseColor("#EA0C01")
        );

        // Set the value
        gauge.setHighValue(0, 0, 100);

        // Each time I will change the value I must write it inside the counter text.
        gauge.setOnEventListener(new ScGauge.OnEventListener() {
            @Override
            public void onValueChange(ScGauge gauge, float lowValue, float highValue, boolean isRunning) {
                // Write the value
                int value = (int) ScGauge.percentageToValue(highValue, 0, 13000);
                counter.setText(Integer.toString(value));
            }
        });
        button.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v) {
                gauge.setHighValue(Float.parseFloat(input.getText().toString()));
                input.setText("");
            }
        });
        //Test gauge
// Find the components
        /*final ScArcGauge gauge = (ScArcGauge) rootView.findViewById(R.id.gauge);
        assert gauge != null;

        final ImageView indicator = (ImageView) rootView.findViewById(R.id.indicator);
        assert indicator != null;

        // Set the center pivot for a right rotation
        indicator.setPivotX(39);
        indicator.setPivotY(88);

        // Set the values.
        gauge.setHighValue(55);

        // Set the filter of the base
        ScFeature base = gauge.findFeature(ScGauge.BASE_IDENTIFIER);
        BlurMaskFilter filter = new BlurMaskFilter(10, BlurMaskFilter.Blur.INNER);
        base.getPainter().setMaskFilter(filter);

        // Writer
        String[] tokens = new String[10];
        for (int index = 0; index < 10; index++) {
            tokens[index] = Integer.toString((index + 1) * 10);
        }
        //gauge.setTextTokens(tokens);

        ScWriter writer = (ScWriter) gauge.findFeature(ScGauge.WRITER_IDENTIFIER);
        //writer.setTokenOffset(0.0f, -40.0f);

        // Each time I will change the value I must write it inside the counter text.
        gauge.setOnEventListener(new ScGauge.OnEventListener() {

            @Override
            public void onValueChange(ScGauge gauge, float lowValue, float highValue, boolean isRunning) {

            }

            public void onValueChange(float lowValue, float highValue) {
                // Convert the percentage value in an angle
                float angle = gauge.percentageToAngle(highValue);
                indicator.setRotation(angle);
            }
        });

        /*gauge.setOnDrawListener(new ScGauge.OnDrawListener() {
            @Override
            public void onDrawContour(ScGauge gauge, ScFeature.ContourInfo info) {

            }

            @Override
            public void onDrawRepetition(ScGauge gauge, ScRepetitions.RepetitionInfo info) {

            }

            @Override
            public void onBeforeDrawCopy(ScCopier.CopyInfo info) {
                // Do nothing
            }

            @Override
            public void onBeforeDrawNotch(ScNotches.NotchInfo info) {
                // Hide the first and the last
                info.visible = info.index > 0 && info.index < info.source.getCount();
            }

            @Override
            public void onBeforeDrawPointer(ScPointer.PointerInfo info) {
                // Do nothing
            }

            @Override
            public void onBeforeDrawToken(ScWriter.TokenInfo info) {
                // Highlight
                int sector = (int) (gauge.getHighValue() / 10);
                info.color = sector == info.index ? Color.BLACK : Color.parseColor("#cccccc");
            }
        });*/
        return rootView;
    }

}
